import {StyleSheet} from 'react-native';

module.exports = StyleSheet.create({

containerHead:{
         position: 'absolute',
         bottom:65,
         right:45,  
         height:175,
         width:175,   
},
    
butCloud0:{
         top:0,
         left:0,
         height:90,
         width:90, 
},
    
butCloud1:{
         top:0,
         left:0,
        
},
       
butCloud2:{
         top:0,
         left:0,
         
},
    
butCloud3:{
         top:0,
         left:0,
           
},
    
butCloud4:{ 
         top:0,
         left:0,
           
},
    
butCloud00:{
         opacity: 1.0,
         bottom:85,
         left:125,
         height:90,
         width:90, 
},
    
butCloud11:{
         position: "relative",
         height:57,
         width:57,  
        
},
    
butCloud22:{
         position: "relative",
         height:57,
         width:57, 
},
    
butCloud33:{
         position: "relative",
         height:57,
         width:57, 
},
    
butCloud44:{
        
         position: "relative",
         height:57,
         width:57, 
        
},
    
});