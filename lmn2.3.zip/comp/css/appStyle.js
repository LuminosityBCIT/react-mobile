import {StyleSheet} from 'react-native';

module.exports = StyleSheet.create({

container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
},

entireBg:{
    flex:1,
    alignSelf:'stretch',
    position:'absolute',
},
    
});